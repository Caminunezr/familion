# Familion App

Aplicación de gestión financiera familiar construida con React y Electron.

## Descripción

Familion ayuda a las familias a gestionar sus cuentas por pagar, pagos, presupuestos y aportes mensuales.

## Tecnologías Utilizadas

*   **Frontend:** React
*   **Base de Datos:** Firebase Realtime Database (RTDB)
*   **Autenticación:** Firebase Authentication
*   **Contenedor Escritorio:** Electron
*   **Gráficos:** Chart.js
*   **(Opcional) Almacenamiento de Archivos:** Firebase Storage

## Instalación y Ejecución

1.  Clona el repositorio.
2.  Instala las dependencias: `npm install`
3.  Configura tus credenciales de Firebase en un archivo `.env` en la raíz del proyecto (ver `.env.example` o las instrucciones anteriores).
4.  Ejecuta en modo desarrollo: `npm run electron:dev`
5.  Construye la aplicación para producción: `npm run electron:build` (generará un instalador en la carpeta `dist`).

<!-- ... (resto del README) ... -->
