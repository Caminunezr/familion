const { app, BrowserWindow } = require('electron');
const path = require('path');
const url = require('url');

// Determinar si estamos en desarrollo
const isDev = process.env.NODE_ENV !== 'production';

function createWindow() {
  // Crear la ventana del navegador.
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      // --- Seguridad Importante ---
      // Es recomendable usar un preload script para exponer APIs de Node de forma segura
      // contextIsolation: true, // Habilitado por defecto en versiones recientes
      // preload: path.join(__dirname, 'preload.js') // Crear este archivo si necesitas IPC
      // Por ahora, si no necesitas IPC inmediato, puedes deshabilitar nodeIntegration temporalmente
      // OJO: Habilitar nodeIntegration directamente es un riesgo de seguridad si cargas contenido remoto.
      // nodeIntegration: true, // ¡Cuidado con esto en producción!
      // contextIsolation: false, // Necesario si nodeIntegration es true
      // --- Fin Seguridad ---

      // Permitir acceso a file:// URLs si es necesario (ej. para FileViewer local)
      // webSecurity: false, // ¡Usar con precaución!
    },
  });

  // Cargar la aplicación React
  if (isDev) {
    // En desarrollo, carga desde el servidor de React (asegúrate que corre en el puerto 3000)
    mainWindow.loadURL('http://localhost:3000');
    // Abrir las DevTools.
    mainWindow.webContents.openDevTools();
  } else {
    // En producción, carga el archivo index.html construido
    mainWindow.loadURL(
      url.format({
        pathname: path.join(__dirname, 'build', 'index.html'),
        protocol: 'file:',
        slashes: true,
      })
    );
  }

  // Evento cuando la ventana se cierra.
  mainWindow.on('closed', function () {
    // Desreferencia el objeto ventana, usualmente guardarías ventanas
    // en un array si tu app soporta multi ventanas, este es el momento
    // cuando deberías borrar el elemento correspondiente.
    // (No aplica en este caso simple)
  });
}

// Este método será llamado cuando Electron haya terminado
// la inicialización y esté listo para crear ventanas del navegador.
// Algunas APIs pueden usarse sólo después de que este evento ocurra.
app.whenReady().then(createWindow);

// Salir cuando todas las ventanas estén cerradas, excepto en macOS.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', function () {
  // En macOS es común recrear una ventana en la app cuando el
  // icono del dock es presionado y no hay otras ventanas abiertas.
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Aquí puedes incluir el resto del código específico del proceso principal de tu aplicación.
// Por ejemplo, manejo de IPC para comunicarse con el proceso de renderizado (React).
