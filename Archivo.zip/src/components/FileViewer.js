import React, { useState, useEffect } from 'react';
import './FileViewer.css';

const FileViewer = ({ filePath }) => {
  const [fileUrl, setFileUrl] = useState(null);
  const [fileType, setFileType] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setFileUrl(null);
    setFileType('');
    setError('');
    setIsLoading(false);

    if (!filePath) {
      return;
    }

    const getFileTypeFromUrl = (url) => {
      try {
        const extension = url.split('.').pop().toLowerCase().split('?')[0];
        if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)) {
          return 'image';
        } else if (extension === 'pdf') {
          return 'pdf';
        } else {
          return 'other';
        }
      } catch (e) {
        return 'other';
      }
    };

    setFileUrl(filePath);
    setFileType(getFileTypeFromUrl(filePath));
  }, [filePath]);

  const renderFile = () => {
    if (isLoading) {
      return <p>Cargando archivo...</p>;
    }
    if (error) {
      return <p className="file-error">Error: {error}</p>;
    }
    if (!fileUrl) {
      return <p>No hay archivo adjunto.</p>;
    }

    switch (fileType) {
      case 'image':
        return <img src={fileUrl} alt="Vista previa" className="file-preview-image" />;
      case 'pdf':
        return (
          <div className="pdf-container">
            <iframe src={fileUrl} title="Vista previa PDF" className="file-preview-pdf"></iframe>
            <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="download-link">
              Abrir PDF en nueva pestaña
            </a>
          </div>
        );
      default:
        return (
          <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="download-link">
            Ver/Descargar Archivo
          </a>
        );
    }
  };

  return (
    <div className="file-viewer">
      {renderFile()}
    </div>
  );
};

export default FileViewer;
