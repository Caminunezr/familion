import React, { useState, useEffect } from 'react';
import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import { ref as databaseRef, push, serverTimestamp } from "firebase/database"; // Cambiado 'ref' a 'databaseRef' para evitar conflicto
import { storage, rtdb } from '../services/firebase'; // Corregido: Ruta dentro de src
import { useAuth } from '../contexts/AuthContext'; // Corregido: Ruta dentro de src
import FileViewer from './FileViewer';
import './PagoForm.css';

const PagoForm = ({ cuenta, onSuccess, onCancel }) => {
  const { currentUser, familyId } = useAuth(); // Obtener familyId del contexto
  const [montoPagado, setMontoPagado] = useState('');
  const [fechaPago, setFechaPago] = useState(new Date().toISOString().split('T')[0]); // Fecha actual por defecto
  const [metodoPago, setMetodoPago] = useState('');
  const [pagadorNombre, setPagadorNombre] = useState(''); // Estado para el nombre del pagador
  const [comprobante, setComprobante] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [previewUrl, setPreviewUrl] = useState(null); // Para previsualizar imagen

  // Lista de nombres (idealmente vendría del contexto o DB)
  const nombresFamilia = ['Camilo', 'Chave', 'Daniela', 'Mia'];

  // Pre-rellenar nombre si el usuario actual está en la lista
  useEffect(() => {
    if (currentUser && currentUser.displayName && nombresFamilia.includes(currentUser.displayName)) {
      setPagadorNombre(currentUser.displayName);
    } else if (currentUser && currentUser.email) {
      // Fallback al email si no hay displayName o no está en la lista
      // Podrías ajustar esto según tu lógica preferida
      const nombreDelEmail = currentUser.email.split('@')[0];
      setPagadorNombre(nombreDelEmail); // O dejarlo vacío: setPagadorNombre('');
    }
  }, [currentUser]);


  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setComprobante(file);
      // Crear URL de previsualización si es imagen
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setPreviewUrl(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setPreviewUrl(null); // No previsualizar si no es imagen
      }
    } else {
      setComprobante(null);
      setPreviewUrl(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validaciones básicas
    if (!montoPagado || isNaN(parseFloat(montoPagado)) || parseFloat(montoPagado) <= 0) {
      setError('Por favor, ingresa un monto válido.');
      setLoading(false);
      return;
    }
    if (!fechaPago) {
      setError('Por favor, selecciona la fecha de pago.');
      setLoading(false);
      return;
    }
    if (!pagadorNombre) {
      setError('Por favor, selecciona quién realizó el pago.');
      setLoading(false);
      return;
    }
    if (!currentUser || !familyId) { // Verificar currentUser y familyId
        setError('Error de autenticación o ID de familia no encontrado. Intenta recargar la página.');
        setLoading(false);
        return;
    }


    try {
      let comprobanteUrlFinal = null;

      // Subir comprobante si existe
      if (comprobante) {
        // Usar familyId en la ruta de Storage
        const filePath = `archivosFamilia/${familyId}/comprobantes/${cuenta.id}_${Date.now()}_${comprobante.name}`;
        console.log("Subiendo comprobante a:", filePath); // Log de la ruta
        const fileRef = storageRef(storage, filePath);
        const snapshot = await uploadBytes(fileRef, comprobante);
        comprobanteUrlFinal = await getDownloadURL(snapshot.ref);
        console.log("Comprobante subido, URL:", comprobanteUrlFinal); // Log de la URL
      }

      // Preparar datos para RTDB
      const pagoData = {
        cuentaId: cuenta.id,
        montoPagado: parseFloat(montoPagado),
        fechaPago: new Date(fechaPago).toISOString(), // Asegurar formato ISO
        metodoPago: metodoPago || null, // Guardar null si está vacío
        pagadorId: currentUser.uid,
        pagadorNombre: pagadorNombre,
        comprobanteUrl: comprobanteUrlFinal,
        fechaRegistro: serverTimestamp() // Usar serverTimestamp
      };

      // <<<--- Log de Depuración --- >>>
      console.log("Intentando guardar pago con datos:", JSON.stringify(pagoData, null, 2));
      console.log("Usando familyId:", familyId);
      const rutaPagos = `familias/${familyId}/pagos`;
      console.log("Referencia de pagos:", rutaPagos);
      // <<<------------------------ >>>

      // Guardar en RTDB usando databaseRef y familyId
      const pagosRef = databaseRef(rtdb, rutaPagos);
      await push(pagosRef, pagoData);

      console.log('Pago registrado exitosamente en RTDB');
      onSuccess(); // Llamar a onSuccess para cerrar el form y refrescar

    } catch (err) {
      console.error("Error al registrar el pago:", err);
      setError(`Error al registrar el pago: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // ... (resto del componente JSX sin cambios)
  return (
    <div className="pago-form-container">
      <h3>Registrar Pago para "{cuenta.nombre}"</h3>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit} className="pago-form">
        {/* Monto Pagado */}
        <div className="form-group">
          <label htmlFor="montoPagado">Monto Pagado *</label>
          <input
            type="number"
            id="montoPagado"
            value={montoPagado}
            onChange={(e) => setMontoPagado(e.target.value)}
            placeholder={`Monto original: $${cuenta.monto.toLocaleString()}`}
            min="0.01"
            step="any"
            required
          />
        </div>

        {/* Fecha de Pago */}
        <div className="form-group">
          <label htmlFor="fechaPago">Fecha de Pago *</label>
          <input
            type="date"
            id="fechaPago"
            value={fechaPago}
            onChange={(e) => setFechaPago(e.target.value)}
            required
          />
        </div>

        {/* Método de Pago */}
        <div className="form-group">
          <label htmlFor="metodoPago">Método de Pago (Opcional)</label>
          <select
            id="metodoPago"
            value={metodoPago}
            onChange={(e) => setMetodoPago(e.target.value)}
          >
            <option value="">Selecciona un método</option>
            <option value="Transferencia">Transferencia</option>
            <option value="Efectivo">Efectivo</option>
            <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
            <option value="Tarjeta de Débito">Tarjeta de Débito</option>
            <option value="Otro">Otro</option>
          </select>
        </div>

        {/* Quién Pagó */}
        <div className="form-group">
          <label htmlFor="pagadorNombre">¿Quién pagó? *</label>
          <select
            id="pagadorNombre"
            value={pagadorNombre}
            onChange={(e) => setPagadorNombre(e.target.value)}
            required
          >
            <option value="" disabled>Selecciona un nombre</option>
            {nombresFamilia.map(nombre => (
              <option key={nombre} value={nombre}>{nombre}</option>
            ))}
            {/* Opción para agregar un nombre que no esté en la lista predefinida, si es necesario */}
            {!nombresFamilia.includes(pagadorNombre) && pagadorNombre && (
              <option value={pagadorNombre}>{pagadorNombre}</option>
            )}
          </select>
        </div>

        {/* Comprobante */}
        <div className="form-group">
          <label htmlFor="comprobante">Comprobante (Opcional)</label>
          <input
            type="file"
            id="comprobante"
            onChange={handleFileChange}
            accept="image/*,.pdf"
          />
          {/* Previsualización del archivo */}
          {previewUrl && <img src={previewUrl} alt="Previsualización" className="file-preview" />}
          {comprobante && !previewUrl && comprobante.type === 'application/pdf' && (
            <p className="file-preview-text">Archivo PDF seleccionado: {comprobante.name}</p>
          )}
          {/* Mostrar si ya existe un comprobante (si se pasa como prop) */}
          {cuenta.comprobanteUrl && !comprobante && (
             <div className="comprobante-existente">
               <p>Comprobante actual:</p>
               <FileViewer filePath={cuenta.comprobanteUrl} isThumbnail={true} />
             </div>
           )}
        </div>

        {/* Botones */}
        <div className="form-buttons">
          <button type="button" onClick={onCancel} className="cancel-button" disabled={loading}>
            Cancelar
          </button>
          <button type="submit" className="submit-button" disabled={loading}>
            {loading ? 'Registrando...' : 'Registrar Pago'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PagoForm;
