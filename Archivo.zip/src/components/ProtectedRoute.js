import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

// Añadir prop 'requireAdmin'
const ProtectedRoute = ({ children, requireAdmin = false }) => {
  const { currentUser, loading } = useAuth();

  if (loading) {
    // Muestra un loader mientras se verifica el estado de autenticación
    // Podrías retornar un componente de carga aquí si lo prefieres
    return <div>Cargando...</div>;
  }

  if (!currentUser) {
    // Si no hay usuario, redirigir a login
    return <Navigate to="/login" />;
  }

  // Si la ruta requiere admin y el usuario no lo es
  if (requireAdmin && !currentUser.isAdmin) {
    // Redirigir a dashboard o a una página de "Acceso Denegado"
    console.warn('[ProtectedRoute] Acceso denegado a ruta admin para usuario no admin.');
    return <Navigate to="/dashboard" />; // O a '/acceso-denegado'
  }

  // Si pasa todas las verificaciones, renderizar el componente hijo
  return children;
};

export default ProtectedRoute;
