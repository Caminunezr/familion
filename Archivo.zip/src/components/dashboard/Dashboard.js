import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../NavBar';
import CuentasList from '../CuentasList';
import CuentaDetalle from '../CuentaDetalle';
import PagoForm from '../PagoForm';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { rtdb } from '../../services/firebase';
import { ref, get, query, orderByChild, equalTo, remove, update } from "firebase/database";
import { useAuth } from '../../contexts/AuthContext';
import ResumenCards from './ResumenCards';
import ProximosVencimientos from './ProximosVencimientos';
import AccionesRapidas from './AccionesRapidas';
import DashboardGraficos from './DashboardGraficos';
import './Dashboard.css';

ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const Dashboard = () => {
  const { currentUser, familyId } = useAuth();
  const navigate = useNavigate();
  const [selectedCuenta, setSelectedCuenta] = useState(null);
  const [showPagoForm, setShowPagoForm] = useState(false);
  const [showDetalle, setShowDetalle] = useState(false);
  const [refreshData, setRefreshData] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('resumen');
  const [subTab, setSubTab] = useState('pendientes');
  const [mesActual, setMesActual] = useState('');
  const [mesAnterior, setMesAnterior] = useState('');
  const [cuentasPendientes, setCuentasPendientes] = useState([]);
  const [cuentasPagadas, setCuentasPagadas] = useState([]);
  const [cuentasMesActual, setCuentasMesActual] = useState([]);
  const [cuentasMesAnterior, setCuentasMesAnterior] = useState([]);
  const [presupuestoMesActual, setPresupuestoMesActual] = useState(null);
  const [presupuestoMesAnterior, setPresupuestoMesAnterior] = useState(null);
  const [aportesMesActual, setAportesMesActual] = useState([]);
  const [aportesMesAnterior, setAportesMesAnterior] = useState([]);
  const [datosPorCategoria, setDatosPorCategoria] = useState({});
  const [comparativaMeses, setComparativaMeses] = useState({});
  const [cuentasProximasVencer, setCuentasProximasVencer] = useState([]);
  const [resumenFinanciero, setResumenFinanciero] = useState({
    totalPendiente: 0,
    totalPagado: 0,
    presupuestoTotal: 0,
    presupuestoRestante: 0,
    progreso: 0,
    tendencia: 0
  });

  useEffect(() => {
    const today = new Date();
    const mesActualStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    const mesAnteriorFecha = new Date(today.getFullYear(), today.getMonth() - 1);
    const mesAnteriorStr = `${mesAnteriorFecha.getFullYear()}-${String(mesAnteriorFecha.getMonth() + 1).padStart(2, '0')}`;
    setMesActual(mesActualStr);
    setMesAnterior(mesAnteriorStr);
  }, []);

  const cargarPresupuestosYAportesRTDB = useCallback(async (mesActualStr, mesAnteriorStr) => {
    if (!currentUser || !familyId) return { presupActual: null, presupAnterior: null, aportesActual: [], aportesAnterior: [] };

    try {
      const presupuestosRef = ref(rtdb, `familias/${familyId}/presupuestos`);
      const aportesRef = ref(rtdb, `familias/${familyId}/aportes`);

      const queryPresupActual = query(presupuestosRef, orderByChild('mes'), equalTo(mesActualStr));
      const queryPresupAnterior = query(presupuestosRef, orderByChild('mes'), equalTo(mesAnteriorStr));

      const [snapPresupActual, snapPresupAnterior] = await Promise.all([
        get(queryPresupActual),
        get(queryPresupAnterior)
      ]);

      let presupActual = null;
      let presupAnterior = null;
      let aportesActual = [];
      let aportesAnterior = [];

      if (snapPresupActual.exists()) {
        const data = snapPresupActual.val();
        const key = Object.keys(data)[0];
        presupActual = { id: key, ...data[key] };
      }
      if (snapPresupAnterior.exists()) {
        const data = snapPresupAnterior.val();
        const key = Object.keys(data)[0];
        presupAnterior = { id: key, ...data[key] };
      }

      const promesasAportes = [];
      if (presupActual) {
        const queryAportesActual = query(aportesRef, orderByChild('presupuestoId'), equalTo(presupActual.id));
        promesasAportes.push(
          get(queryAportesActual).then(snap => {
            if (snap.exists()) {
              const data = snap.val();
              aportesActual = Object.keys(data).map(key => ({ id: key, ...data[key] }));
            }
          })
        );
      }
      if (presupAnterior) {
        const queryAportesAnterior = query(aportesRef, orderByChild('presupuestoId'), equalTo(presupAnterior.id));
        promesasAportes.push(
          get(queryAportesAnterior).then(snap => {
            if (snap.exists()) {
              const data = snap.val();
              aportesAnterior = Object.keys(data).map(key => ({ id: key, ...data[key] }));
            }
          })
        );
      }

      await Promise.all(promesasAportes);

      return { presupActual, presupAnterior, aportesActual, aportesAnterior };

    } catch (error) {
      console.error('Error al cargar presupuestos y aportes desde RTDB:', error);
      throw error;
    }
  }, [currentUser, familyId]);

  const procesarCuentasYPagosRTDB = useCallback((cuentasObj, pagosObj, mesActualStr, mesAnteriorStr) => {
    try {
      const cuentasArray = cuentasObj ? Object.keys(cuentasObj).map(key => ({ id: key, ...cuentasObj[key] })) : [];
      const pagosArray = pagosObj ? Object.keys(pagosObj).map(key => ({ id: key, ...pagosObj[key] })) : [];

      const infosPorCuenta = pagosArray.reduce((mapa, pago) => {
        if (!mapa[pago.cuentaId]) {
          mapa[pago.cuentaId] = { totalPagado: 0, fechaUltimoPago: null };
        }
        mapa[pago.cuentaId].totalPagado += Number(pago.montoPagado || 0);
        if (!mapa[pago.cuentaId].fechaUltimoPago || new Date(pago.fechaPago) > new Date(mapa[pago.cuentaId].fechaUltimoPago)) {
          mapa[pago.cuentaId].fechaUltimoPago = pago.fechaPago;
        }
        return mapa;
      }, {});

      const hoy = new Date(); hoy.setHours(0,0,0,0);
      const enDiezDias = new Date(hoy); enDiezDias.setDate(hoy.getDate() + 10);
      const inicioMesActual = new Date(mesActualStr + '-01T00:00:00');
      const finMesActual = new Date(inicioMesActual); finMesActual.setMonth(finMesActual.getMonth() + 1); finMesActual.setDate(0); finMesActual.setHours(23,59,59,999);
      const inicioMesAnterior = new Date(mesAnteriorStr + '-01T00:00:00');
      const finMesAnterior = new Date(inicioMesAnterior); finMesAnterior.setMonth(finMesAnterior.getMonth() + 1); finMesAnterior.setDate(0); finMesAnterior.setHours(23,59,59,999);

      const pendientes = [];
      const pagadas = [];
      const mesActualCuentas = [];
      const mesAnteriorCuentas = [];
      const proximasVencer = [];

      cuentasArray.forEach(cuenta => {
        const infoPagos = infosPorCuenta[cuenta.id] || { totalPagado: 0, fechaUltimoPago: null };
        const totalPagado = infoPagos.totalPagado;
        const montoCuenta = Number(cuenta.monto || 0);
        const estaPagada = montoCuenta > 0 && totalPagado >= montoCuenta;

        const cuentaConPago = { ...cuenta, totalPagado, estaPagada, fechaUltimoPago: infoPagos.fechaUltimoPago };

        if (estaPagada) pagadas.push(cuentaConPago);
        else pendientes.push(cuentaConPago);

        if (cuenta.fechaVencimiento) {
          try {
            const fechaVencimiento = new Date(cuenta.fechaVencimiento);
            if (!isNaN(fechaVencimiento)) {
              if (fechaVencimiento >= inicioMesActual && fechaVencimiento <= finMesActual) mesActualCuentas.push(cuentaConPago);
              if (fechaVencimiento >= inicioMesAnterior && fechaVencimiento <= finMesAnterior) mesAnteriorCuentas.push(cuentaConPago);
              if (!estaPagada && fechaVencimiento >= hoy && fechaVencimiento <= enDiezDias) proximasVencer.push(cuentaConPago);
            } else {
              console.warn(`Fecha de vencimiento inválida para cuenta ${cuenta.id}: ${cuenta.fechaVencimiento}`);
            }
          } catch (dateError) {
             console.warn(`Error al parsear fecha de vencimiento para cuenta ${cuenta.id}: ${cuenta.fechaVencimiento}`, dateError);
          }
        }
      });

      pendientes.sort((a, b) => (a.fechaVencimiento && b.fechaVencimiento) ? new Date(a.fechaVencimiento) - new Date(b.fechaVencimiento) : (a.fechaVencimiento ? -1 : 1));
      proximasVencer.sort((a, b) => new Date(a.fechaVencimiento) - new Date(b.fechaVencimiento));

      setCuentasPendientes(pendientes);
      setCuentasPagadas(pagadas);
      setCuentasMesActual(mesActualCuentas);
      setCuentasMesAnterior(mesAnteriorCuentas);
      setCuentasProximasVencer(proximasVencer);

    } catch (error) {
      console.error('Error al procesar cuentas y pagos desde RTDB:', error);
      throw error;
    }
  }, []);

  useEffect(() => {
    if (!mesActual || !mesAnterior || !currentUser) {
      setLoading(false);
      setError(currentUser ? null : "Usuario no autenticado.");
      setCuentasPendientes([]);
      setCuentasPagadas([]);
      return;
    }

    if (!familyId) {
      setLoading(false);
      setError("ID de familia no encontrado para este usuario.");
      setCuentasPendientes([]);
      setCuentasPagadas([]);
      return;
    }

    const fetchAllDataRTDB = async () => {
      setLoading(true);
      setError(null);
      try {
        if (!currentUser) {
          throw new Error("Usuario no autenticado al intentar cargar datos.");
        }

        const familiaCuentasRef = ref(rtdb, `familias/${familyId}/cuentas`);
        const familiaPagosRef = ref(rtdb, `familias/${familyId}/pagos`);

        const [cuentasSnapshot, pagosSnapshot] = await Promise.all([
          get(familiaCuentasRef),
          get(familiaPagosRef)
        ]);

        const { presupActual, presupAnterior, aportesActual, aportesAnterior } = await cargarPresupuestosYAportesRTDB(mesActual, mesAnterior);

        setPresupuestoMesActual(presupActual);
        setPresupuestoMesAnterior(presupAnterior);
        setAportesMesActual(aportesActual);
        setAportesMesAnterior(aportesAnterior);

        procesarCuentasYPagosRTDB(
          cuentasSnapshot.exists() ? cuentasSnapshot.val() : null,
          pagosSnapshot.exists() ? pagosSnapshot.val() : null,
          mesActual,
          mesAnterior
        );

      } catch (error) {
        console.error('Error detallado al cargar datos desde RTDB:', error);
        let errorMessage = 'Ocurrió un error al cargar los datos financieros desde Firebase.';
        if (error.code === 'PERMISSION_DENIED') {
          errorMessage = 'Permiso denegado. Verifica las reglas de seguridad y la estructura de datos (/familias/{familyId}/...).';
        } else if (error.message) {
          errorMessage += ` Detalles: ${error.message}`;
        }
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchAllDataRTDB();
  }, [mesActual, mesAnterior, currentUser, familyId, refreshData, cargarPresupuestosYAportesRTDB, procesarCuentasYPagosRTDB]);

  useEffect(() => {
    if (loading) return;

    const totalPendienteCalc = cuentasPendientes.reduce((sum, c) => sum + c.monto, 0);
    const totalPagadoMesActual = cuentasPagadas
        .filter(c => c.fechaUltimoPago && new Date(c.fechaUltimoPago) >= new Date(mesActual + '-01T00:00:00'))
        .reduce((sum, c) => sum + c.totalPagado, 0);
    const totalPagadoMesAnterior = cuentasPagadas
        .filter(c => c.fechaUltimoPago && new Date(c.fechaUltimoPago) >= new Date(mesAnterior + '-01T00:00:00') && new Date(c.fechaUltimoPago) < new Date(mesActual + '-01T00:00:00'))
        .reduce((sum, c) => sum + c.totalPagado, 0);

    const presupuestoTotalCalc = presupuestoMesActual?.montoObjetivo || 0;
    const aportadoTotalCalc = aportesMesActual.reduce((sum, a) => sum + a.monto, 0);
    const presupuestoRestanteCalc = Math.max(0, presupuestoTotalCalc - aportadoTotalCalc);
    const progresoCalc = presupuestoTotalCalc > 0 ? Math.min((aportadoTotalCalc / presupuestoTotalCalc) * 100, 100) : 0;

    let tendenciaCalc = 0;
    if (totalPagadoMesAnterior > 0) {
        tendenciaCalc = ((totalPagadoMesActual - totalPagadoMesAnterior) / totalPagadoMesAnterior) * 100;
    } else if (totalPagadoMesActual > 0) {
        tendenciaCalc = 100;
    }

    setResumenFinanciero({
        totalPendiente: totalPendienteCalc,
        totalPagado: totalPagadoMesActual,
        presupuestoTotal: presupuestoTotalCalc,
        presupuestoRestante: presupuestoRestanteCalc,
        progreso: progresoCalc,
        tendencia: tendenciaCalc
    });

    const gastosPorCategoria = cuentasPagadas
        .reduce((acc, cuenta) => {
            const categoria = cuenta.categoria || 'Sin Categoría';
            acc[categoria] = (acc[categoria] || 0) + cuenta.monto;
            return acc;
        }, {});

    setDatosPorCategoria({
        labels: Object.keys(gastosPorCategoria),
        datasets: [{
            data: Object.values(gastosPorCategoria),
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
        }]
    });

    const montoTotalMesActual = cuentasMesActual.reduce((sum, c) => sum + c.monto, 0);
    const montoTotalMesAnterior = cuentasMesAnterior.reduce((sum, c) => sum + c.monto, 0);

    setComparativaMeses({
        labels: [formatoMes(mesAnterior), formatoMes(mesActual)],
        datasets: [{
            label: 'Monto Total Cuentas',
            data: [montoTotalMesAnterior, montoTotalMesActual],
            backgroundColor: ['#FFCE56', '#36A2EB'],
        }]
    });

  }, [loading, cuentasPendientes, cuentasPagadas, cuentasMesActual, cuentasMesAnterior, presupuestoMesActual, aportesMesActual, mesActual, mesAnterior]);

  const handleSelectCuenta = useCallback((cuenta) => {
    setSelectedCuenta(cuenta);
    setShowDetalle(true);
    setShowPagoForm(false);
  }, []);

  const handleEliminarCuenta = useCallback(async (cuentaId) => {
    if (!currentUser) {
      setError("Usuario no autenticado.");
      return;
    }
    if (!familyId) {
      setError("ID de familia no encontrado.");
      return;
    }
    if (window.confirm('¿Estás seguro de que quieres eliminar esta cuenta y sus pagos asociados? Esta acción no se puede deshacer.')) {
      try {
        setLoading(true);

        const pagosRef = ref(rtdb, `familias/${familyId}/pagos`);
        const pagosQuery = query(pagosRef, orderByChild('cuentaId'), equalTo(cuentaId));
        const pagosSnapshot = await get(pagosQuery);

        if (pagosSnapshot.exists()) {
          const updates = {};
          pagosSnapshot.forEach((childSnapshot) => {
              updates[childSnapshot.key] = null;
          });
          await update(ref(rtdb, `familias/${familyId}/pagos`), updates);
          console.log(`Pagos asociados a la cuenta ${cuentaId} eliminados.`);
        }

        const cuentaRef = ref(rtdb, `familias/${familyId}/cuentas/${cuentaId}`);
        await remove(cuentaRef);
        console.log(`Cuenta ${cuentaId} eliminada de RTDB.`);

        setRefreshData(prev => prev + 1);
        if (selectedCuenta?.id === cuentaId) {
          setSelectedCuenta(null);
          setShowDetalle(false);
          setShowPagoForm(false);
        }

      } catch (error) {
        console.error('Error al eliminar cuenta en RTDB:', error);
        setError('Error al eliminar la cuenta desde Firebase.');
      } finally {
        setLoading(false);
      }
    }
  }, [currentUser, familyId, selectedCuenta?.id]);

  const formatoMes = (mesString) => {
    const [año, mes] = mesString.split('-');
    const nombresMeses = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    return `${nombresMeses[parseInt(mes) - 1]} ${año}`;
  };

  const formatoFecha = (fechaString) => {
    if (!fechaString) return 'Sin fecha';
    const fecha = new Date(fechaString);
    return fecha.toLocaleDateString('es-ES');
  };

  const ErrorDisplay = ({ message }) => (
    <div className="error-container">
      <div className="error-icon">⚠️</div>
      <h3>Error al cargar datos</h3>
      <p>{message || 'Ocurrió un error inesperado.'}</p>
      <button 
        className="retry-button"
        onClick={() => setRefreshData(prev => prev + 1)}
      >
        Intentar de nuevo
      </button>
    </div>
  );

  if (loading) {
    return (
      <div className="dashboard-page">
        <NavBar />
        <div className="dashboard-loading">
          <div className="loading-spinner"></div>
          <p>Cargando información financiera...</p>
        </div>
      </div>
    );
  }

  if (error || (currentUser && !familyId && !loading)) {
    const message = error || "ID de familia no encontrado para este usuario.";
    return (
      <div className="dashboard-page">
        <NavBar />
        <div className="dashboard-container">
          <ErrorDisplay message={message} />
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <NavBar />
      
      <div className="dashboard-container">
        <div className="dashboard-header">
          <h2>Panel Principal</h2>
          <div className="periodo-actual">
            <span className="periodo-label">Periodo actual:</span>
            <span className="periodo-value">{formatoMes(mesActual)}</span>
          </div>
        </div>
        
        <div className="dashboard-tabs">
          <button 
            className={`tab-button ${activeTab === 'resumen' ? 'active' : ''}`}
            onClick={() => setActiveTab('resumen')}
          >
            Resumen
          </button>
          <button 
            className={`tab-button ${activeTab === 'cuentas' ? 'active' : ''}`}
            onClick={() => setActiveTab('cuentas')}
          >
            Cuentas ({cuentasPendientes.length})
          </button>
          <button 
            className={`tab-button ${activeTab === 'presupuesto' ? 'active' : ''}`}
            onClick={() => setActiveTab('presupuesto')}
          >
            Presupuesto
          </button>
        </div>
        
        {!showDetalle && !showPagoForm ? (
          <div className="dashboard-content">
            {activeTab === 'resumen' && (
              <div className="tab-content resumen-tab">
                <ResumenCards
                  resumenFinanciero={resumenFinanciero}
                  cuentasPendientes={cuentasPendientes}
                />

                <div className="proximas-y-acciones">
                  <ProximosVencimientos
                    cuentasProximasVencer={cuentasProximasVencer}
                    handleSelectCuenta={handleSelectCuenta}
                    formatoFecha={formatoFecha}
                  />
                  <AccionesRapidas
                    irAGestionCuentas={() => navigate('/gestion-cuentas')}
                    irAPresupuesto={() => navigate('/presupuesto')}
                    setActiveTab={setActiveTab}
                  />
                </div>

                <DashboardGraficos
                  datosPorCategoria={datosPorCategoria}
                  comparativaMeses={comparativaMeses}
                />
              </div>
            )}

            {activeTab === 'cuentas' && (
              <div className="tab-content cuentas-tab">
                <div className="cuentas-header">
                  <div className="cuentas-tabs">
                    <button 
                      className={`cuenta-tab ${subTab === 'pendientes' ? 'active' : ''}`} 
                      onClick={() => setSubTab('pendientes')}
                    >
                      Cuentas Pendientes ({cuentasPendientes.length})
                    </button>
                    <button 
                      className={`cuenta-tab ${subTab === 'pagadas' ? 'active' : ''}`} 
                      onClick={() => setSubTab('pagadas')}
                    >
                      Cuentas Pagadas ({cuentasPagadas.length})
                    </button>
                  </div>
                  <button 
                    className="nueva-cuenta-button"
                    onClick={() => navigate('/gestion-cuentas')}
                  >
                    <span className="btn-icon">+</span> Nueva Cuenta
                  </button>
                </div>
                
                <div className="cuentas-container">
                  {subTab === 'pendientes' && cuentasPendientes.length === 0 ? (
                    <div className="empty-state">
                      <div className="empty-icon">📋</div>
                      <p>No tienes cuentas pendientes</p>
                      <button className="action-button" onClick={() => navigate('/gestion-cuentas')}>
                        Crear una cuenta
                      </button>
                    </div>
                  ) : subTab === 'pagadas' && cuentasPagadas.length === 0 ? (
                    <div className="empty-state">
                      <div className="empty-icon">✅</div>
                      <p>No tienes cuentas pagadas registradas</p>
                    </div>
                  ) : (
                    <CuentasList 
                      cuentas={subTab === 'pendientes' ? cuentasPendientes : cuentasPagadas} 
                      onSelectCuenta={handleSelectCuenta}
                      estadoLabel={subTab === 'pendientes' ? 'Pendiente' : 'Pagada'}
                      onDeleteCuenta={subTab === 'pagadas' ? handleEliminarCuenta : undefined}
                    />
                  )}
                </div>
              </div>
            )}

            {activeTab === 'presupuesto' && (
              <div className="tab-content presupuesto-tab">
                {presupuestoMesActual ? (
                  <div className="presupuesto-resumen">
                    <div className="presupuesto-header">
                      <div className="presupuesto-titulo">
                        <h3>Presupuesto: {formatoMes(presupuestoMesActual.mes)}</h3>
                        <span className="presupuesto-creador">
                          Creado por: {presupuestoMesActual.creadorNombre || 'Usuario'}
                        </span>
                      </div>
                      <button 
                        className="ver-presupuesto-button"
                        onClick={() => navigate('/presupuesto')}
                      >
                        Ver Detalles Completos
                      </button>
                    </div>
                    
                    <div className="presupuesto-stats">
                      <div className="stat-card aporte-card">
                        <div className="stat-icon">💰</div>
                        <div className="stat-content">
                          <div className="stat-label">Aporte Mensual</div>
                          <div className="stat-value">
                            ${(presupuestoMesActual.montoAporte || presupuestoMesActual.montoObjetivo).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="stat-card aportado-card">
                        <div className="stat-icon">💵</div>
                        <div className="stat-content">
                          <div className="stat-label">Total Aportado</div>
                          <div className="stat-value">
                            ${aportesMesActual.reduce((sum, a) => sum + a.monto, 0).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="stat-card pendiente-card">
                        <div className="stat-icon">⏳</div>
                        <div className="stat-content">
                          <div className="stat-label">Pendiente por Aportar</div>
                          <div className="stat-value">
                            ${Math.max(0, (presupuestoMesActual.montoAporte || presupuestoMesActual.montoObjetivo) - 
                              aportesMesActual.reduce((sum, a) => sum + a.monto, 0)).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="stat-card numero-card">
                        <div className="stat-icon">🧾</div>
                        <div className="stat-content">
                          <div className="stat-label">Aportes Realizados</div>
                          <div className="stat-value">
                            {aportesMesActual.length}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="progreso-container">
                      <div className="progreso-label">
                        <span>Progreso de Aportes</span>
                        <span className="progreso-porcentaje">
                          {Math.min(
                            (aportesMesActual.reduce((sum, a) => sum + a.monto, 0) / 
                            (presupuestoMesActual.montoAporte || presupuestoMesActual.montoObjetivo)) * 100, 
                            100
                          ).toFixed(0)}%
                        </span>
                      </div>
                      <div className="progreso-barra">
                        <div 
                          className="progreso-relleno"
                          style={{ 
                            width: `${Math.min(
                              (aportesMesActual.reduce((sum, a) => sum + a.monto, 0) / 
                              (presupuestoMesActual.montoAporte || presupuestoMesActual.montoObjetivo)) * 100, 
                              100
                            )}%` 
                          }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="aportes-recientes">
                      <div className="aportes-header">
                        <h4>Aportes Recientes</h4>
                        <button 
                          className="ir-presupuesto-button"
                          onClick={() => navigate('/presupuesto')}
                        >
                          Registrar Aporte
                        </button>
                      </div>
                      
                      {aportesMesActual.length === 0 ? (
                        <div className="empty-state">No hay aportes registrados para este mes</div>
                      ) : (
                        <div className="aportes-lista">
                          {aportesMesActual.slice(0, 5).map(aporte => (
                            <div key={aporte.id} className={`aporte-item ${aporte.tipoPago === 'cuenta' ? 'aporte-cuenta' : ''}`}>
                              <div className="aporte-fecha">{formatoFecha(aporte.fechaAporte)}</div>
                              <div className="aporte-info">
                                <div className="aporte-monto">${aporte.monto.toLocaleString()}</div>
                                {aporte.tipoPago === 'cuenta' && (
                                  <div className="aporte-tipo">Pago de cuenta: {aporte.cuentaNombre}</div>
                                )}
                              </div>
                            </div>
                          ))}
                          {aportesMesActual.length > 5 && (
                            <div className="ver-mas">
                              <button 
                                className="ver-mas-button"
                                onClick={() => navigate('/presupuesto')}
                              >
                                Ver todos los aportes
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="presupuesto-vacio">
                    <div className="vacio-icon">📊</div>
                    <h3>No hay presupuesto para {formatoMes(mesActual)}</h3>
                    <p>Crea un presupuesto para poder hacer un seguimiento de tus gastos mensuales.</p>
                    <button className="crear-presupuesto-button" onClick={() => navigate('/presupuesto')}>
                      Crear Presupuesto
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : showPagoForm ? (
          <PagoForm 
            cuenta={selectedCuenta} 
            onSuccess={() => {
              setShowPagoForm(false);
              setSelectedCuenta(null);
              setShowDetalle(false);
              setRefreshData((prev) => prev + 1);
            }}
            onCancel={() => {
              setShowPagoForm(false);
              if (selectedCuenta) setShowDetalle(true);
              else setSelectedCuenta(null);
            }}
          />
        ) : (
          <CuentaDetalle 
            cuenta={selectedCuenta}
            onBackClick={() => {
              setShowDetalle(false);
              setSelectedCuenta(null);
            }}
            onPagoClick={() => {
              setShowPagoForm(true);
              setShowDetalle(false);
            }}
          />
        )}
        
        {cuentasProximasVencer.length > 0 && activeTab !== 'resumen' && (
          <div className="alertas-flotantes">
            <div className="alerta-proximos-vencimientos">
              <span className="alerta-icon">⚠️</span>
              <span>Tienes {cuentasProximasVencer.length} cuenta(s) próxima(s) a vencer</span>
              <button 
                className="ver-alerta-button"
                onClick={() => setActiveTab('resumen')}
              >
                Ver
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
