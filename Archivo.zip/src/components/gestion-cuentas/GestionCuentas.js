import React, { useState, useEffect, useCallback, useMemo } from 'react';
import NavBar from '../NavBar';
import { useAuth } from '../../contexts/AuthContext';
import { rtdb } from '../../services/firebase';
import { ref, get, set, push, remove, query, orderByChild, equalTo, update, serverTimestamp } from "firebase/database";
import { saveFile } from '../../utils/fileStorage';
import GestionCuentasHeader from './GestionCuentasHeader';
import GestionCuentasResumen from './GestionCuentasResumen';
import GestionCuentasFiltros from './GestionCuentasFiltros';
import GestionCuentasListado from './GestionCuentasListado';
import GestionCuentasForm from './GestionCuentasForm';
import GestionCuentasDetalle from './GestionCuentasDetalle';
import './GestionCuentas.css';

const estadoInicialFormulario = {
  id: null,
  monto: '',
  fechaEmision: '',
  fechaVencimiento: '',
  categoria: '',
  proveedor: '',
  descripcion: '',
  facturaUrl: '',
  creadorNombre: '',
};

const GestionCuentas = () => {
  const { currentUser, familyId } = useAuth();
  const [cuentas, setCuentas] = useState([]);
  const [filteredCuentas, setFilteredCuentas] = useState([]);
  const [resumen, setResumen] = useState({ total: 0, pendientes: 0, montoTotal: 0, proximas: 0 });
  const [formData, setFormData] = useState(estadoInicialFormulario);
  const [categorias, setCategorias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formLoading, setFormLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showDetallePanel, setShowDetallePanel] = useState(false);
  const [cuentaParaVerDetalle, setCuentaParaVerDetalle] = useState(null);
  const [pagoInfo, setPagoInfo] = useState(null);
  const [loadingPagoInfo, setLoadingPagoInfo] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortCriteria, setSortCriteria] = useState('fechaCreacion');
  const [sortDirection, setSortDirection] = useState('desc');
  const [error, setError] = useState(null);
  const [formError, setFormError] = useState(null);
  const [detalleError, setDetalleError] = useState(null);

  const proveedoresPorCategoria = useMemo(() => ({
    Luz: ['Enel'],
    Agua: ['Aguas Andinas'],
    Internet: ['Mundo', 'Entel', 'Wom', 'Claro', 'VTR'],
    Gas: ['Lipigas', 'Gasco', 'Abastible'],
    'Utiles de Aseo': [],
    Otros: [],
  }), []);

  useEffect(() => {
    setCategorias(['Luz', 'Agua', 'Gas', 'Internet', 'Utiles de Aseo', 'Otros']);
  }, []);

  const cargarDatos = useCallback(async () => {
    if (!currentUser) {
      setError("Usuario no autenticado.");
      setLoading(false);
      return;
    }
    if (!familyId) {
      setError("ID de familia no encontrado para este usuario. Contacta al administrador.");
      setLoading(false);
      setCuentas([]);
      setResumen({ total: 0, pendientes: 0, montoTotal: 0, proximas: 0 });
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const familiaCuentasRef = ref(rtdb, `familias/${familyId}/cuentas`);
      const familiaPagosRef = ref(rtdb, `familias/${familyId}/pagos`);

      const [cuentasSnapshot, pagosSnapshot] = await Promise.all([
        get(familiaCuentasRef),
        get(familiaPagosRef)
      ]);

      const cuentasObj = cuentasSnapshot.exists() ? cuentasSnapshot.val() : {};
      const pagosObj = pagosSnapshot.exists() ? pagosSnapshot.val() : {};

      const cuentasArray = Object.keys(cuentasObj).map(key => ({ id: key, ...cuentasObj[key] }));
      const pagosArray = Object.keys(pagosObj).map(key => ({ id: key, ...pagosObj[key] }));

      const pagosPorCuentaId = pagosArray.reduce((acc, pago) => {
        if (!acc[pago.cuentaId]) acc[pago.cuentaId] = [];
        acc[pago.cuentaId].push(pago);
        acc[pago.cuentaId].sort((a, b) => new Date(b.fechaPago) - new Date(a.fechaPago));
        return acc;
      }, {});

      const cuentasConPagos = cuentasArray.map(cuenta => {
        const pagosAsociados = pagosPorCuentaId[cuenta.id] || [];
        const totalPagado = pagosAsociados.reduce((sum, p) => sum + Number(p.montoPagado || 0), 0);
        const montoCuenta = Number(cuenta.monto || 0);
        const estaPagada = montoCuenta > 0 && totalPagado >= montoCuenta;
        return {
          ...cuenta,
          pagos: pagosAsociados,
          totalPagado,
          estaPagada,
          fechaUltimoPago: pagosAsociados.length > 0 ? pagosAsociados[0].fechaPago : null
        };
      });

      setCuentas(cuentasConPagos);

      const total = cuentasConPagos.length;
      const pendientes = cuentasConPagos.filter(c => !c.estaPagada).length;
      const montoTotal = cuentasConPagos.reduce((sum, c) => sum + (Number(c.monto) || 0), 0);
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      const unaSemana = new Date(hoy);
      unaSemana.setDate(hoy.getDate() + 7);
      const proximas = cuentasConPagos.filter(c =>
        !c.estaPagada &&
        c.fechaVencimiento &&
        new Date(c.fechaVencimiento) >= hoy &&
        new Date(c.fechaVencimiento) <= unaSemana
      ).length;

      setResumen({ total, pendientes, montoTotal, proximas });

    } catch (err) {
      console.error("Error cargando datos desde Firebase RTDB:", err);
      let errorMessage = "No se pudieron cargar las cuentas desde Firebase.";
      if (err.code === 'PERMISSION_DENIED') {
        errorMessage = 'Permiso denegado. Verifica las reglas de seguridad y la estructura de datos (/familias/{familyId}/...).';
      } else if (err.message) {
        errorMessage += ` Detalles: ${err.message}`;
      }
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [currentUser, familyId]);

  useEffect(() => {
    cargarDatos();
  }, [cargarDatos]);

  useEffect(() => {
    let resultado = [...cuentas];

    if (searchTerm) {
      const lowerSearchTerm = searchTerm.toLowerCase();
      resultado = resultado.filter(cuenta =>
        cuenta.nombre?.toLowerCase().includes(lowerSearchTerm) ||
        cuenta.proveedor?.toLowerCase().includes(lowerSearchTerm) ||
        cuenta.categoria?.toLowerCase().includes(lowerSearchTerm)
      );
    }

    resultado.sort((a, b) => {
      let valA = a[sortCriteria];
      let valB = b[sortCriteria];

      if (sortCriteria.includes('fecha')) {
        const dateA = valA ? new Date(valA).getTime() : (sortDirection === 'asc' ? Infinity : -Infinity);
        const dateB = valB ? new Date(valB).getTime() : (sortDirection === 'asc' ? Infinity : -Infinity);
        valA = dateA;
        valB = dateB;
      } else if (sortCriteria === 'monto') {
        valA = Number(valA) || 0;
        valB = Number(valB) || 0;
      } else {
        valA = String(valA || '').toLowerCase();
        valB = String(valB || '').toLowerCase();
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    setFilteredCuentas(resultado);
  }, [cuentas, searchTerm, sortCriteria, sortDirection]);

  useEffect(() => {
    const categoriaSeleccionada = formData.categoria;
    if (!showForm) return;

    if (!categoriaSeleccionada) {
      if (formData.proveedor !== '') {
        setFormData(prev => ({ ...prev, proveedor: '' }));
      }
      return;
    }

    const proveedores = proveedoresPorCategoria[categoriaSeleccionada] || [];

    if (proveedores.length === 1) {
      if (formData.proveedor !== proveedores[0]) {
        setFormData(prev => ({ ...prev, proveedor: proveedores[0] }));
      }
    } else if (proveedores.length > 1) {
      if (formData.proveedor && !proveedores.includes(formData.proveedor)) {
        setFormData(prev => ({ ...prev, proveedor: '' }));
      }
    } else {
      if (formData.proveedor !== '') {
        setFormData(prev => ({ ...prev, proveedor: '' }));
      }
    }
  }, [formData.categoria, formData.proveedor, showForm]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setFormError(null);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSortChange = (e) => {
    setSortCriteria(e.target.value);
  };

  const toggleSortDirection = () => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  };

  const handleAbrirFormularioNuevo = () => {
    setFormData(estadoInicialFormulario);
    setCuentaParaVerDetalle(null);
    setShowDetallePanel(false);
    setFormError(null);
    setShowForm(true);
  };

  const handleAbrirPanel = (cuenta) => {
    setFormError(null);
    setDetalleError(null);
    setCuentaParaVerDetalle(cuenta);
    setShowDetallePanel(true);
    setShowForm(false);
    setFormData(estadoInicialFormulario);
  };

  const handleCancelar = () => {
    setShowForm(false);
    setShowDetallePanel(false);
    setCuentaParaVerDetalle(null);
    setPagoInfo(null);
    setFormError(null);
    setDetalleError(null);
    setFormData(estadoInicialFormulario);
  };

  const handleEditarDesdeDetalle = (cuenta) => {
    if (!cuenta) return;

    const fechaEmisionFormato = cuenta.fechaEmision ? cuenta.fechaEmision.split('T')[0] : '';
    const fechaVencimientoFormato = cuenta.fechaVencimiento ? cuenta.fechaVencimiento.split('T')[0] : '';

    setFormData({
      id: cuenta.id,
      monto: cuenta.monto || '',
      fechaEmision: fechaEmisionFormato,
      fechaVencimiento: fechaVencimientoFormato,
      categoria: cuenta.categoria || '',
      proveedor: cuenta.proveedor || '',
      descripcion: cuenta.descripcion || '',
      facturaUrl: cuenta.facturaUrl || '',
      creadorNombre: cuenta.creadorNombre || '',
      fechaCreacion: cuenta.fechaCreacion,
    });

    setShowDetallePanel(false);
    setShowForm(true);
    setCuentaParaVerDetalle(null);
    setFormError(null);
  };

  const handleGuardarCuenta = async (formDataFromForm, facturaFile) => {
    const currentFormData = formDataFromForm;

    if (!currentUser) {
      setError("Usuario no autenticado.");
      return;
    }
    if (!familyId) {
      setError("ID de familia no encontrado.");
      return;
    }

    const creador = currentFormData.creadorNombre || currentUser.displayName || 'Usuario';

    setFormLoading(true);
    setError(null);
    setFormError(null);

    if (!currentFormData.categoria || !currentFormData.monto || !currentFormData.fechaVencimiento || !creador) {
      setFormError("Por favor completa todos los campos obligatorios (*).");
      setFormLoading(false);
      return;
    }

    const requiereDescripcion = currentFormData.categoria === 'Otros' || currentFormData.categoria === 'Utiles de Aseo';
    if (requiereDescripcion && !currentFormData.descripcion?.trim()) {
      setFormError(`Para la categoría '${currentFormData.categoria}', la descripción es obligatoria y será usada como nombre.`);
      setFormLoading(false);
      return;
    }

    const provDisponibles = proveedoresPorCategoria[currentFormData.categoria] || [];
    if (provDisponibles.length > 1 && !currentFormData.proveedor) {
      setFormError(`Para la categoría '${currentFormData.categoria}', debes seleccionar un proveedor.`);
      setFormLoading(false);
      return;
    }

    if (isNaN(parseFloat(currentFormData.monto)) || parseFloat(currentFormData.monto) <= 0) {
      setFormError('El monto debe ser un número mayor que cero.');
      setFormLoading(false);
      return;
    }

    let generatedName = currentFormData.categoria;
    if (requiereDescripcion) {
      generatedName = currentFormData.descripcion.trim();
    }

    if (!generatedName) {
      setFormError("No se pudo generar un nombre para la cuenta. Revisa la categoría y descripción.");
      setFormLoading(false);
      return;
    }

    try {
      let facturaUrlParaGuardar = currentFormData.facturaUrl || null;

      if (facturaFile) {
        const storagePathPrefix = `archivosFamilia/${familyId}/facturas`; 
        console.log("Subiendo nuevo archivo:", facturaFile.name, "a", storagePathPrefix);
        facturaUrlParaGuardar = await saveFile(facturaFile, storagePathPrefix); 
        console.log("Archivo subido, URL:", facturaUrlParaGuardar);
      }

      const dataToSave = {
        nombre: generatedName,
        monto: parseFloat(currentFormData.monto),
        fechaEmision: currentFormData.fechaEmision ? new Date(currentFormData.fechaEmision).toISOString() : null,
        fechaVencimiento: currentFormData.fechaVencimiento ? new Date(currentFormData.fechaVencimiento).toISOString() : null,
        categoria: currentFormData.categoria,
        proveedor: provDisponibles.length === 1 ? provDisponibles[0] : (currentFormData.proveedor || ''),
        descripcion: currentFormData.descripcion?.trim() || '',
        creadorId: currentUser.uid,
        creadorNombre: creador,
        fechaActualizacion: serverTimestamp(),
        facturaUrl: facturaUrlParaGuardar,
      };

      const cuentasRef = ref(rtdb, `familias/${familyId}/cuentas`);

      if (currentFormData.id) {
        const cuentaEspecificaRef = ref(rtdb, `familias/${familyId}/cuentas/${currentFormData.id}`);
        await update(cuentaEspecificaRef, dataToSave);
      } else {
        dataToSave.fechaCreacion = serverTimestamp();
        await push(cuentasRef, dataToSave);
      }

      setShowForm(false);
      setFormData(estadoInicialFormulario);
      await cargarDatos();

    } catch (err) {
      console.error("Error guardando cuenta o subiendo archivo:", err);
      setFormError("Error al guardar la cuenta: " + err.message);
    } finally {
      setFormLoading(false);
    }
  };

  const handleEliminarCuenta = useCallback(async (cuentaId) => {
    if (!currentUser) {
      setError("Usuario no autenticado.");
      return;
    }
    if (!familyId) {
      setError("ID de familia no encontrado.");
      return;
    }
    if (window.confirm('¿Estás seguro de que quieres eliminar esta cuenta y sus pagos asociados? Esta acción no se puede deshacer.')) {
      try {
        setLoading(true);

        const pagosRef = ref(rtdb, `familias/${familyId}/pagos`);
        const pagosQuery = query(pagosRef, orderByChild('cuentaId'), equalTo(cuentaId));
        const pagosSnapshot = await get(pagosQuery);
        if (pagosSnapshot.exists()) {
          const updates = {};
          pagosSnapshot.forEach((childSnapshot) => {
            updates[childSnapshot.key] = null;
          });
          await update(ref(rtdb, `familias/${familyId}/pagos`), updates);
        }

        const cuentaRef = ref(rtdb, `familias/${familyId}/cuentas/${cuentaId}`);
        await remove(cuentaRef);

        await cargarDatos();
        if (cuentaParaVerDetalle?.id === cuentaId) {
          handleCancelar();
        }

      } catch (error) {
        console.error('Error al eliminar cuenta en RTDB:', error);
        setError('Error al eliminar la cuenta desde Firebase.');
      } finally {
        setLoading(false);
      }
    }
  }, [currentUser, familyId, cargarDatos, cuentaParaVerDetalle?.id]);

  useEffect(() => {
    const fetchPagoInfo = async () => {
      if (showDetallePanel && cuentaParaVerDetalle?.id && currentUser && familyId) {
        setLoadingPagoInfo(true);
        setPagoInfo(null);
        setDetalleError(null);
        try {
          const response = await get(ref(rtdb, `familias/${familyId}/pagos`));
          if (!response.exists()) {
            throw new Error("No se encontraron pagos asociados.");
          }
          const pagosAsociados = Object.values(response.val()).filter(pago => pago.cuentaId === cuentaParaVerDetalle.id);

          pagosAsociados.sort((a, b) => new Date(b.fechaPago) - new Date(a.fechaPago));

          setPagoInfo(pagosAsociados.length > 0 ? pagosAsociados[0] : null);

        } catch (err) {
          console.error("Error obteniendo información del pago desde Firebase RTDB:", err);
          setDetalleError("No se pudo obtener la información del pago desde Firebase.");
        } finally {
          setLoadingPagoInfo(false);
        }
      }
    };

    fetchPagoInfo();
  }, [showDetallePanel, cuentaParaVerDetalle, currentUser, familyId]);

  return (
    <div className="gestion-cuentas-page">
      <NavBar />
      <div className="gestion-cuentas-container">
        <GestionCuentasHeader onAbrirFormularioNuevo={handleAbrirFormularioNuevo} />
        <GestionCuentasResumen resumen={resumen} />
        <GestionCuentasFiltros
          searchTerm={searchTerm}
          onSearchChange={handleSearchChange}
          sortCriteria={sortCriteria}
          onSortChange={handleSortChange}
          sortDirection={sortDirection}
          onToggleSortDirection={toggleSortDirection}
        />

        <div className={`main-content-gc ${showForm || showDetallePanel ? 'panel-visible' : ''}`}>
          <div className="cuentas-list-area">
            {!familyId && !loading && !currentUser && <p className="error-message">Debes iniciar sesión.</p>}
            {!familyId && !loading && currentUser && <p className="error-message">ID de familia no configurado para tu usuario.</p>}

            <GestionCuentasListado
              loading={loading}
              error={error}
              cuentas={filteredCuentas}
              searchTerm={searchTerm}
              onAbrirPanel={handleAbrirPanel}
              onAbrirFormularioNuevo={handleAbrirFormularioNuevo}
              onEliminarCuenta={handleEliminarCuenta}
            />
          </div>

          {showDetallePanel && (
            <GestionCuentasDetalle
              cuenta={cuentaParaVerDetalle}
              pagoInfo={pagoInfo}
              loadingPagoInfo={loadingPagoInfo}
              onCancelar={handleCancelar}
              onEditarCuenta={handleEditarDesdeDetalle}
              error={detalleError}
            />
          )}

          {showForm && (
            <GestionCuentasForm
              formData={formData}
              onInputChange={handleInputChange}
              onGuardarCuenta={handleGuardarCuenta}
              onCancelar={handleCancelar}
              categorias={categorias}
              proveedoresPorCategoria={proveedoresPorCategoria}
              formLoading={formLoading}
              error={formError}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default GestionCuentas;