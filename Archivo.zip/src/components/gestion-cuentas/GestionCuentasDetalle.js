import React, { useState } from 'react';
// Asume que existe un componente FileViewer similar a este:
// import FileViewer from '../shared/FileViewer'; 

// Placeholder simple si FileViewer no existe
const FileViewer = ({ filePath }) => {
  if (!filePath) return null;
  const isPdf = filePath.toLowerCase().includes('.pdf');
  const isImage = ['.jpg', '.jpeg', '.png', '.gif'].some(ext => filePath.toLowerCase().includes(ext));

  return (
    <div style={{ marginTop: '15px', border: '1px solid #eee', padding: '10px' }}>
      {isPdf ? (
        <iframe src={filePath} width="100%" height="400px" title="Vista previa PDF"></iframe>
      ) : isImage ? (
        <img src={filePath} alt="Vista previa" style={{ maxWidth: '100%', maxHeight: '400px' }} />
      ) : (
        <p>No se puede previsualizar este tipo de archivo. <a href={filePath} target="_blank" rel="noopener noreferrer">Descargar</a></p>
      )}
    </div>
  );
};

const formatoFecha = (fechaISO) => {
  if (!fechaISO) return 'N/A';
  try {
    const date = new Date(fechaISO);
    if (isNaN(date.getTime())) {
      const timestamp = parseInt(fechaISO, 10);
      if (!isNaN(timestamp)) {
        return new Date(timestamp).toLocaleDateString('es-CL');
      }
      return 'Fecha inválida';
    }
    return date.toLocaleDateString('es-CL');
  } catch (e) {
    console.error("Error formateando fecha:", fechaISO, e);
    return 'Error fecha';
  }
};

const formatoMoneda = (valor) => {
  const num = Number(valor);
  return num.toLocaleString('es-CL', { style: 'currency', currency: 'CLP' });
};

const GestionCuentasDetalle = ({ cuenta, pagoInfo, loadingPagoInfo, onCancelar, onEditarCuenta, error }) => {
  const [showFacturaPreview, setShowFacturaPreview] = useState(false);
  const [showComprobantePreview, setShowComprobantePreview] = useState(false);

  if (!cuenta) return null;

  const handleEditClick = () => {
    if (onEditarCuenta) {
      onEditarCuenta(cuenta); // Llamar a la función pasada desde el padre
    }
  };

  return (
    <div className="form-area-gc detalle-panel">
      <div className="panel-header">
        <h3>Detalles de la Cuenta</h3>
        <button onClick={onCancelar} className="close-panel-btn" aria-label="Cerrar panel">&times;</button>
      </div>
      <div className="panel-content">
        {error && <div className="error-message">{error}</div>}

        <div className="detalle-seccion">
          <h4>Información General</h4>
          <div className="detalle-item">
            <span className="detalle-label">Nombre:</span>
            <span>{cuenta.nombre}</span>
          </div>
          <div className="detalle-item">
            <span className="detalle-label">Monto:</span>
            <span>{formatoMoneda(cuenta.monto)}</span>
          </div>
          <div className="detalle-item">
            <span className="detalle-label">Categoría:</span>
            <span>{cuenta.categoria}</span>
          </div>
          {cuenta.proveedor && (
            <div className="detalle-item">
              <span className="detalle-label">Proveedor:</span>
              <span>{cuenta.proveedor}</span>
            </div>
          )}
          <div className="detalle-item">
            <span className="detalle-label">Fecha Vencimiento:</span>
            <span>{formatoFecha(cuenta.fechaVencimiento)}</span>
          </div>
          {cuenta.fechaEmision && (
            <div className="detalle-item">
              <span className="detalle-label">Fecha Emisión:</span>
              <span>{formatoFecha(cuenta.fechaEmision)}</span>
            </div>
          )}
          {cuenta.descripcion && (
            <div className="detalle-item">
              <span className="detalle-label">Descripción:</span>
              <span>{cuenta.descripcion}</span>
            </div>
          )}
          <div className="detalle-item">
            <span className="detalle-label">Creado por:</span>
            <span>{cuenta.creadorNombre || 'Desconocido'}</span>
          </div>
          <div className="detalle-item">
            <span className="detalle-label">Fecha Creación:</span>
            <span>{formatoFecha(cuenta.fechaCreacion)}</span>
          </div>
          <div className="detalle-item">
            <span className="detalle-label">Última Actualización:</span>
            <span>{formatoFecha(cuenta.fechaActualizacion)}</span>
          </div>
        </div>

        <div className="detalle-seccion">
          <h4>Factura / Boleta</h4>
          {cuenta.facturaUrl ? (
            <>
              <button
                className="btn-ver-archivo"
                onClick={() => setShowFacturaPreview(!showFacturaPreview)}
              >
                {showFacturaPreview ? 'Ocultar' : 'Ver'} Factura
              </button>
              {showFacturaPreview && <FileViewer filePath={cuenta.facturaUrl} />}
            </>
          ) : (
            <p>No hay factura/boleta adjunta.</p>
          )}
        </div>

        <div className="detalle-seccion">
          <h4>Información de Pago</h4>
          {loadingPagoInfo ? (
            <p>Cargando información de pago...</p>
          ) : pagoInfo ? (
            <div className="comprobante-pago">
              <div className="detalle-item">
                <span className="detalle-label">Estado:</span>
                <span className={`cuenta-estado-badge ${cuenta.estaPagada ? 'pagada' : 'pendiente'}`}>
                  {cuenta.estaPagada ? 'Pagada' : 'Pendiente'}
                </span>
              </div>
              <div className="detalle-item">
                <span className="detalle-label">Fecha de Pago:</span>
                <span>{formatoFecha(pagoInfo.fechaPago)}</span>
              </div>
              <div className="detalle-item">
                <span className="detalle-label">Monto Pagado:</span>
                <span>{formatoMoneda(pagoInfo.montoPagado)}</span>
              </div>
              <div className="detalle-item">
                <span className="detalle-label">Medio de Pago:</span>
                <span>{pagoInfo.medioPago || 'No especificado'}</span>
              </div>
              {pagoInfo.comprobanteUrl ? (
                <>
                  <button
                    className="btn-ver-archivo"
                    onClick={() => setShowComprobantePreview(!showComprobantePreview)}
                    style={{ marginTop: '10px' }}
                  >
                    {showComprobantePreview ? 'Ocultar' : 'Ver'} Comprobante de Pago
                  </button>
                  {showComprobantePreview && <FileViewer filePath={pagoInfo.comprobanteUrl} />}
                </>
              ) : (
                <p style={{ marginTop: '10px' }}>No hay comprobante de pago adjunto.</p>
              )}
            </div>
          ) : (
            <p>Esta cuenta aún no ha sido pagada o no se encontró información del pago.</p>
          )}
        </div>
      </div>
      <div className="panel-actions">
        {!cuenta.estaPagada && (
          <button onClick={handleEditClick} className="submit-button">Editar</button>
        )}
        <button onClick={onCancelar} className="cancel-button">Cerrar</button>
      </div>
    </div>
  );
};

export default GestionCuentasDetalle;
