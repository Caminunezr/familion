import React, { useState, useEffect } from 'react';

const GestionCuentasForm = ({
  formData: initialFormData,
  onInputChange,
  onGuardarCuenta,
  onCancelar,
  categorias,
  proveedoresPorCategoria,
  formLoading,
  error
}) => {
  const [facturaFile, setFacturaFile] = useState(null);
  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    setFormData(initialFormData);
    setFacturaFile(null);
  }, [initialFormData]);

  const proveedoresDisponibles = formData.categoria ? (proveedoresPorCategoria[formData.categoria] || []) : [];
  const mostrarSelectorProveedor = proveedoresDisponibles.length > 1;
  const proveedorAutoSeleccionado = proveedoresDisponibles.length === 1 ? proveedoresDisponibles[0] : '';
  const requiereDescripcion = formData.categoria === 'Otros' || formData.categoria === 'Utiles de Aseo';

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFacturaFile(e.target.files[0]);
    } else {
      setFacturaFile(null);
    }
  };

  const handleFormInputChange = (e) => {
    onInputChange(e);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onGuardarCuenta(formData, facturaFile);
  };

  const getFileNameFromUrl = (url) => {
    if (!url) return '';
    try {
      const decodedUrl = decodeURIComponent(url);
      const parts = decodedUrl.split('/');
      const fileNameWithToken = parts.pop() || '';
      const fileName = fileNameWithToken.split('?')[0];
      const nameParts = fileName.split('_');
      if (nameParts.length > 1) {
        nameParts.shift();
        return nameParts.join('_');
      }
      return fileName;
    } catch (error) {
      console.error("Error extrayendo nombre de archivo:", error);
      return 'archivo adjunto';
    }
  };

  return (
    <div className="form-area-gc">
      <div className="form-header">
        <h3>{formData.id ? 'Editar Cuenta' : 'Nueva Cuenta'}</h3>
        <button onClick={onCancelar} className="close-form-btn" aria-label="Cerrar formulario">&times;</button>
      </div>
      <form onSubmit={handleSubmit} className="form-container">
        <div className="panel-content">
          {error && <div className="error-message">{error}</div>}

          <div className="form-group">
            <label htmlFor="categoria">Categoría *</label>
            <select
              id="categoria"
              name="categoria"
              value={formData.categoria}
              onChange={handleFormInputChange}
              required
            >
              <option value="">Selecciona una categoría</option>
              {categorias.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {mostrarSelectorProveedor && (
            <div className="form-group">
              <label htmlFor="proveedor">Proveedor *</label>
              <select
                id="proveedor"
                name="proveedor"
                value={formData.proveedor}
                onChange={handleFormInputChange}
                required
              >
                <option value="">Selecciona un proveedor</option>
                {proveedoresDisponibles.map(prov => (
                  <option key={prov} value={prov}>{prov}</option>
                ))}
              </select>
            </div>
          )}

          {!mostrarSelectorProveedor && proveedorAutoSeleccionado && (
            <div className="form-group">
              <label>Proveedor</label>
              <input
                type="text"
                value={proveedorAutoSeleccionado}
                disabled
                className="form-input-disabled"
              />
            </div>
          )}

          <div className="form-group">
            <label htmlFor="monto">Monto *</label>
            <input
              type="number"
              id="monto"
              name="monto"
              value={formData.monto}
              onChange={handleFormInputChange}
              required
              min="0"
              step="0.01"
            />
          </div>

          <div className="form-group">
            <label htmlFor="fechaVencimiento">Fecha de Vencimiento *</label>
            <input
              type="date"
              id="fechaVencimiento"
              name="fechaVencimiento"
              value={formData.fechaVencimiento}
              onChange={handleFormInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="fechaEmision">Fecha de Emisión</label>
            <input
              type="date"
              id="fechaEmision"
              name="fechaEmision"
              value={formData.fechaEmision}
              onChange={handleFormInputChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="descripcion">
              Descripción {requiereDescripcion ? '*' : ''}
            </label>
            <textarea
              id="descripcion"
              name="descripcion"
              value={formData.descripcion}
              onChange={handleFormInputChange}
              rows="3"
              maxLength={200}
              required={requiereDescripcion}
            ></textarea>
            {requiereDescripcion && <small>La descripción será usada como nombre para esta categoría.</small>}
          </div>

          <div className="form-group">
            <label htmlFor="creadorNombre">Tu Nombre (Creador) *</label>
            <input
              type="text"
              id="creadorNombre"
              name="creadorNombre"
              value={formData.creadorNombre}
              onChange={handleFormInputChange}
              required
              maxLength={50}
            />
          </div>

          <div className="form-group">
            <label htmlFor="facturaFile">Factura/Boleta (PDF, JPG, PNG)</label>
            {formData.id && formData.facturaUrl && !facturaFile && (
              <div className="factura-actual-info">
                Archivo actual: {getFileNameFromUrl(formData.facturaUrl)}
              </div>
            )}
            {facturaFile && (
              <div className="factura-actual-info" style={{ color: '#198754' }}>
                Nuevo archivo: {facturaFile.name}
              </div>
            )}
            <input
              type="file"
              id="facturaFile"
              name="facturaFile"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileChange}
            />
          </div>
        </div>
        <div className="form-buttons">
          <button type="button" className="cancel-button" onClick={onCancelar} disabled={formLoading}>
            Cancelar
          </button>
          <button type="submit" className="submit-button" disabled={formLoading}>
            {formLoading ? 'Guardando...' : (formData.id ? 'Actualizar Cuenta' : 'Guardar Cuenta')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default GestionCuentasForm;
