import React from 'react';

const GestionCuentasListado = ({
  loading,
  error,
  cuentas, // Renombrado desde filteredCuentas para claridad en el componente hijo
  searchTerm,
  onAbrirPanel,
  onAbrirFormularioNuevo // Para el botón en estado vacío
}) => {

  if (loading) {
    return <p>Cargando cuentas...</p>;
  }

  if (error && !cuentas.length) {
    return <p className="error-message">{error}</p>;
  }

  if (cuentas.length === 0 && !searchTerm) {
    return (
      <div className="empty-state-gc">
        <div className="empty-icon-gc">📋</div>
        <h3>No se encontraron cuentas</h3>
        <p>No tienes cuentas creadas. ¡Crea tu primera cuenta!</p>
        <button className="crear-cuenta-btn-empty" onClick={onAbrirFormularioNuevo}>
          + Crear Nueva Cuenta
        </button>
      </div>
    );
  }

  if (cuentas.length === 0 && searchTerm) {
    return <p>No se encontraron cuentas que coincidan con "{searchTerm}".</p>;
  }

  return (
    <div className="cuentas-list-gc">
      {cuentas.map(cuenta => (
        <div key={cuenta.id} className={`cuenta-card-gc ${cuenta.estaPagada ? 'pagada' : 'pendiente'}`}>
          <div className="cuenta-card-info">
            <div className="cuenta-card-header">
              <span className="cuenta-nombre">{cuenta.nombre}</span>
              <span className={`cuenta-estado-badge ${cuenta.estaPagada ? 'pagada' : 'pendiente'}`}>
                {cuenta.estaPagada ? 'Pagada' : 'Pendiente'}
              </span>
            </div>
            <div className="cuenta-card-details">
              <span><strong>Categoría:</strong> {cuenta.categoria}</span>
              {cuenta.proveedor && <span><strong>Proveedor:</strong> {cuenta.proveedor}</span>}
              <span><strong>Monto:</strong> ${Number(cuenta.monto || 0).toLocaleString()}</span>
              <span><strong>Vence:</strong> {cuenta.fechaVencimiento ? new Date(cuenta.fechaVencimiento).toLocaleDateString() : 'N/A'}</span>
              {cuenta.facturaUrl && <span className="factura-indicator">📄 Factura adjunta</span>}
            </div>
          </div>
          <div className="cuenta-card-actions">
            {cuenta.estaPagada ? (
              <button className="btn-ver-detalles" onClick={() => onAbrirPanel(cuenta)}>
                Ver Detalles
              </button>
            ) : (
              <button className="btn-editar" onClick={() => onAbrirPanel(cuenta)}>
                Editar
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default GestionCuentasListado;
