import React, { useState, useEffect, useMemo } from 'react';
import NavBar from '../NavBar'; // <-- Añadir esta importación
import HistorialFiltros from './HistorialFiltros';
import HistorialResumen from './HistorialResumen';
import HistorialGraficos from './HistorialGraficos';
import HistorialInterpretacion from './HistorialInterpretacion';
import HistorialPeriodos from './HistorialPeriodos';
import { procesarDatosHistorial } from '../../utils/historialUtils';
import './Historial.css';

const Historial = ({ cuentas = [], presupuesto = null, aportes = [], mes = '' }) => {
  const [filtros, setFiltros] = useState({
    periodo: mes || 'mes_anterior',
    categoria: 'todas',
    tipo: 'todos',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const datosProcesados = useMemo(() => {
    const cuentasValidas = Array.isArray(cuentas) ? cuentas : [];
    const estructuraVacia = {
      resumen: { totalCuentas: 0, totalMonto: 0, totalPagado: 0, porcentajePagado: 0 },
      graficos: { categorias: { labels: [], datasets: [] }, pagosVsVencimientos: { labels: [], datasets: [] } },
      interpretacion: { mensajePrincipal: "No hay datos para mostrar.", consejos: [] },
      comparativa: { porPeriodo: [] }
    };

    if (cuentasValidas.length === 0) {
      return estructuraVacia;
    }
    try {
      const resumen = procesarDatosHistorial(cuentasValidas, presupuesto, aportes);

      return {
        resumen: resumen || estructuraVacia.resumen,
        graficos: estructuraVacia.graficos,
        interpretacion: estructuraVacia.interpretacion,
        comparativa: estructuraVacia.comparativa
      };
    } catch (err) {
      console.error("Error procesando datos del historial:", err);
      setError("Error al procesar los datos del historial.");
      return estructuraVacia;
    }
  }, [cuentas, presupuesto, aportes]);

  const handleFiltroChange = (nuevosFiltros) => {
    setFiltros(prev => ({ ...prev, ...nuevosFiltros }));
  };

  const formatoMes = (mesString) => {
    if (!mesString) return "Periodo no definido";
    const [año, mesNum] = mesString.split('-');
    const nombresMeses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    return `${nombresMeses[parseInt(mesNum) - 1]} ${año}`;
  };

  if (loading) return <p>Cargando historial...</p>;
  if (error) return <p className="error-message">{error}</p>;

  const resumenData = datosProcesados.resumen;
  const graficosData = datosProcesados.graficos;
  const interpretacionData = datosProcesados.interpretacion;
  const comparativaData = datosProcesados.comparativa;

  return (
    <div className="historial-page"> {/* Puedes usar esta clase o crear una nueva */}
      <NavBar /> {/* <-- Renderizar NavBar aquí */}
      <div className="historial-container">
        <div className="historial-header">
          <div className="historial-titulo">
            <h3>Historial Financiero</h3>
            <div className="historial-periodo">Periodo: {formatoMes(mes)}</div>
          </div>
        </div>

        <HistorialResumen resumen={resumenData} />
        <HistorialGraficos graficos={graficosData} />
        <HistorialInterpretacion interpretacion={interpretacionData} />
        <HistorialPeriodos comparativa={comparativaData} />

        <div className="historial-tabla">
          <div className="historial-tabla-header">
            <div className="columna nombre">Nombre</div>
            <div className="columna monto">Monto</div>
            <div className="columna vencimiento">Vencimiento</div>
            <div className="columna estado">Estado</div>
          </div>
          <div className="historial-tabla-body">
            {(Array.isArray(cuentas) ? cuentas : []).map(cuenta => (
              <div key={cuenta.id} className="historial-fila">
                <div className="columna nombre">{cuenta.nombre}</div>
                <div className="columna monto">${(cuenta.monto || 0).toLocaleString()}</div>
                <div className="columna vencimiento">{cuenta.fechaVencimiento ? new Date(cuenta.fechaVencimiento).toLocaleDateString() : 'N/A'}</div>
                <div className="columna estado">
                  <span className={`estado-badge ${cuenta.estaPagada ? 'pagado' : 'pendiente'}`}>
                    {cuenta.estaPagada ? 'Pagado' : 'Pendiente'}
                  </span>
                </div>
              </div>
            ))}
            {(Array.isArray(cuentas) ? cuentas : []).length === 0 && (
              <div className="empty-state">No hay cuentas para mostrar en este periodo.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Historial;
