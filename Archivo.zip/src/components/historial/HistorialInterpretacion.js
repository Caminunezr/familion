import React from 'react';

// Estructura por defecto
const defaultInterpretacionData = {
  mensajePrincipal: "No hay datos suficientes para generar una interpretación.",
  consejos: [],
  totalMonto: 0, // Añadir propiedades esperadas
  totalPagado: 0
};

const HistorialInterpretacion = ({ interpretacion = defaultInterpretacionData }) => {
  // Acceso seguro
  const mensajePrincipal = interpretacion?.mensajePrincipal || defaultInterpretacionData.mensajePrincipal;
  const consejos = interpretacion?.consejos || defaultInterpretacionData.consejos;
  const totalMonto = interpretacion?.totalMonto || defaultInterpretacionData.totalMonto; // Acceso seguro
  const totalPagado = interpretacion?.totalPagado || defaultInterpretacionData.totalPagado; // Acceso seguro

  return (
    <div className="interpretacion-container card"> {/* Añadir clase card si aplica */}
      <h3>Interpretación y Consejos</h3>
      <p className="mensaje-principal">{mensajePrincipal}</p>
      {/* Mostrar totales si existen */}
      {totalMonto > 0 && (
        <p>Monto total de cuentas en el periodo: ${totalMonto.toLocaleString()}</p>
      )}
       {totalPagado > 0 && (
        <p>Total pagado en el periodo: ${totalPagado.toLocaleString()}</p>
      )}
      {consejos.length > 0 && (
        <div className="consejos-lista">
          <h4>Consejos:</h4>
          <ul>
            {consejos.map((consejo, index) => (
              <li key={index}>{consejo}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default HistorialInterpretacion;
