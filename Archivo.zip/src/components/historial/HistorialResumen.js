import React from 'react';

// Añadir valores por defecto para la prop 'resumen'
const HistorialResumen = ({ resumen = { totalCuentas: 0, totalMonto: 0, totalPagado: 0, porcentajePagado: 0 } }) => {
  // Acceder a las propiedades de forma segura
  const totalCuentas = resumen.totalCuentas || 0;
  const totalMonto = resumen.totalMonto || 0;
  const totalPagado = resumen.totalPagado || 0;
  const porcentajePagado = resumen.porcentajePagado || 0;

  return (
    <div className="historial-resumen">
      <div className="resumen-item">
        <div className="resumen-valor">{totalCuentas}</div>
        <div className="resumen-label">Total Cuentas</div>
      </div>
      <div className="resumen-item">
        <div className="resumen-valor">${totalMonto.toLocaleString()}</div>
        <div className="resumen-label">Monto Total</div>
      </div>
      <div className="resumen-item">
        <div className="resumen-valor">${totalPagado.toLocaleString()}</div>
        <div className="resumen-label">Total Pagado</div>
      </div>
      <div className="resumen-item">
        <div className="resumen-valor">{porcentajePagado.toFixed(0)}%</div>
        <div className="resumen-label">Pagado</div>
      </div>
    </div>
  );
};

export default HistorialResumen;
