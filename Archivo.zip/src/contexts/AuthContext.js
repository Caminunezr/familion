import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail
} from 'firebase/auth';
import { auth, rtdb } from '../services/firebase'; // Importar rtdb
import { ref, get, set, serverTimestamp } from "firebase/database"; // Importar ref, get, set, serverTimestamp

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [familyId, setFamilyId] = useState(null); // Estado para el ID de la familia
  const [loading, setLoading] = useState(true);

  function signup(email, password, displayName) {
    return createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Actualizar perfil de Firebase Auth
        return updateProfile(userCredential.user, { displayName: displayName })
          .then(() => {
            // Crear perfil en RTDB después de actualizar el perfil de Auth
            const userProfileRef = ref(rtdb, `perfilesUsuario/${userCredential.user.uid}`);
            // --- Asignación inicial de familia ---
            // TODO: Implementar lógica de invitación o asignación de familia.
            // Por ahora, asignamos un ID de familia por defecto o null.
            // ¡IMPORTANTE! Este ID debe existir en la rama /familias/ para que las reglas funcionen.
            // Puedes crear manualmente una entrada /familias/DEFAULT_FAMILY en Firebase.
            const initialFamilyId = "DEFAULT_FAMILY"; // O null si prefieres asignación manual
            return set(userProfileRef, {
              email: userCredential.user.email,
              displayName: displayName,
              fechaCreacion: new Date().toISOString(),
              idDeLaFamilia: initialFamilyId, // Guardar ID de familia
              isAdmin: false // Por defecto no es admin
            }).then(() => {
              setFamilyId(initialFamilyId); // Establecer familyId en el contexto
              return userCredential; // Devolver credenciales originales
            });
          });
      });
  }

  function login(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  function logout() {
    setFamilyId(null); // Limpiar familyId al cerrar sesión
    return signOut(auth);
  }

  function resetPassword(email) {
    return sendPasswordResetEmail(auth, email);
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      console.log('Auth state changed: User', user ? `logged in ${user.uid}` : 'logged out');
      if (user) {
        // Usuario ha iniciado sesión, obtener perfil de RTDB
        const userProfileRef = ref(rtdb, `perfilesUsuario/${user.uid}`);
        try {
          const snapshot = await get(userProfileRef);
          if (snapshot.exists()) {
            const profileData = snapshot.val();
            console.log('Perfil encontrado en RTDB:', profileData);

            // --- Log Adicional para Diagnóstico ---
            const isAdminValueFromDB = profileData.isAdmin;
            const isAdminProcessed = isAdminValueFromDB === true;
            console.log(`[AuthContext] isAdmin leído de DB: ${isAdminValueFromDB} (Tipo: ${typeof isAdminValueFromDB}), Procesado como: ${isAdminProcessed}`);
            // --- Fin Log Adicional ---

            // Combinar datos de Auth y RTDB
            const combinedUser = {
              uid: user.uid,
              email: user.email,
              displayName: profileData.displayName || user.displayName, // Usar de RTDB si existe
              isAdmin: isAdminProcessed, // Usar el valor procesado
              familyId: profileData.idDeLaFamilia || null, // Usar de RTDB
              // ...otros datos de 'user' o 'profileData' que necesites
            };
            setCurrentUser(combinedUser);
            setFamilyId(combinedUser.familyId); // Actualizar familyId en el contexto
            console.log(`Usuario ${user.uid} asignado a familyId: ${combinedUser.familyId}, isAdmin: ${combinedUser.isAdmin}`);
          } else {
            // Perfil no encontrado en RTDB - ¡Esto no debería pasar si el signup funciona!
            console.warn(`Perfil no encontrado en RTDB para el usuario ${user.uid}. Creando perfil básico.`);
            const initialFamilyId = "DEFAULT_FAMILY"; // O null si prefieres forzar la asignación manual
            const basicProfile = {
              email: user.email,
              displayName: user.displayName || user.email.split('@')[0],
              fechaCreacion: serverTimestamp(), // Usar serverTimestamp si es posible, o new Date().toISOString()
              idDeLaFamilia: initialFamilyId,
              isAdmin: false // Por defecto no es admin
            };
            await set(userProfileRef, basicProfile);
            setCurrentUser({ ...user, ...basicProfile }); // Usar datos del perfil básico
            setFamilyId(initialFamilyId);
            console.log(`Perfil básico creado para ${user.uid} con familyId: ${initialFamilyId}`);
          }
        } catch (error) {
          console.error("Error al obtener perfil de RTDB:", error);
          // Mantener al usuario logueado pero sin perfil/familia
          setCurrentUser(user); // Solo con datos de Auth
          setFamilyId(null);
        }
      } else {
        // Usuario ha cerrado sesión
        console.log("Auth state changed: User logged out");
        setCurrentUser(null);
        setFamilyId(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value = {
    currentUser,
    familyId, // Proveer familyId
    signup,
    login,
    logout,
    resetPassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
