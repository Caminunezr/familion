import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database'; // Para Realtime Database
import { getStorage } from 'firebase/storage'; // Importar getStorage

// Tu configuración de Firebase Web app
// Asegúrate de que estas variables de entorno estén definidas (ej. en un archivo .env)
// y que tengan el prefijo REACT_APP_
const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.REACT_APP_FIREBASE_DATABASE_URL, // Importante para RTDB
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID || 'familion-4730c', // Asegúrate que projectId también sea correcto
  
  // --- FORZAR EL VALOR CORRECTO ---
  // Cambia esta línea para usar directamente el nombre correcto del bucket:
  storageBucket: 'familion-4730c', 
  // --- Ya no depende de process.env ---

  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID
};

// --- Verificación ---
// Añade este console.log para depurar en la consola de Electron
console.log('Firebase Config API Key:', firebaseConfig.apiKey ? 'Encontrada' : 'NO ENCONTRADA');
if (!firebaseConfig.apiKey) {
  console.error("¡ERROR! La API Key de Firebase no está definida. Verifica tus variables de entorno (REACT_APP_FIREBASE_API_KEY).");
}

// El console.log ahora debería mostrar 'familion-4730c'
console.log('Firebase Config Storage Bucket:', firebaseConfig.storageBucket); 
// --- Fin Verificación ---


// Inicializar Firebase
const app = initializeApp(firebaseConfig);

// Inicializar servicios que necesitas
const auth = getAuth(app);
const rtdb = getDatabase(app); // Instancia de Realtime Database
const storage = getStorage(app); // Inicializar Storage

// Exportar los servicios inicializados
export {
  app,
  auth,
  rtdb, // Exportar RTDB
  storage // Exportar Storage
};
