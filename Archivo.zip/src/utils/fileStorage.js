import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from '../services/firebase'; // Asegúrate que storage esté exportado desde firebase.js

/**
 * Sube un archivo a Firebase Storage y devuelve su URL de descarga.
 * @param {File} file - El archivo a subir.
 * @param {string} pathPrefix - El prefijo de la ruta en Storage (ej: 'familias/familyId/facturas').
 * @returns {Promise<string>} - La URL de descarga del archivo subido.
 * @throws {Error} - Si ocurre un error durante la subida.
 */
export const saveFile = async (file, pathPrefix) => {
  if (!file) {
    throw new Error("No se proporcionó ningún archivo para guardar.");
  }
  if (!pathPrefix) {
    throw new Error("Se requiere un prefijo de ruta para guardar el archivo.");
  }

  try {
    // Generar un nombre de archivo único para evitar sobrescrituras
    // Usar timestamp + nombre original (sanitizado si es necesario)
    const uniqueFileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const fullPath = `${pathPrefix}/${uniqueFileName}`; // pathPrefix es 'familias/${familyId}/facturas'

    console.log(`Subiendo archivo a Storage en: ${fullPath}`);

    // Crear una referencia al archivo en Storage
    const fileRef = storageRef(storage, fullPath);

    // Subir el archivo
    const snapshot = await uploadBytes(fileRef, file);
    console.log('Archivo subido con éxito:', snapshot.metadata.name);

    // Obtener la URL de descarga
    const downloadURL = await getDownloadURL(snapshot.ref);
    console.log('URL de descarga obtenida:', downloadURL);

    return downloadURL;

  } catch (error) {
    console.error("Error al subir el archivo a Firebase Storage:", error);
    // Puedes personalizar el mensaje de error según el código de error de Storage si lo necesitas
    // ej: if (error.code === 'storage/unauthorized') { ... }
    throw new Error(`Error al subir el archivo: ${error.message}`);
  }
};

// Opcional: Función para borrar un archivo (si necesitas reemplazar o eliminar)
/**
 * Elimina un archivo de Firebase Storage usando su URL de descarga.
 * @param {string} fileUrl - La URL de descarga del archivo a eliminar.
 * @returns {Promise<void>}
 * @throws {Error} - Si ocurre un error durante la eliminación.
 */
// export const deleteFileByUrl = async (fileUrl) => {
//   if (!fileUrl) {
//     console.warn("No se proporcionó URL para eliminar archivo.");
//     return;
//   }
//   try {
//     const fileRef = storageRef(storage, fileUrl); // Obtener referencia desde la URL
//     await deleteObject(fileRef);
//     console.log("Archivo eliminado con éxito:", fileUrl);
//   } catch (error) {
//     // Ignorar error si el archivo no existe (puede haber sido borrado previamente)
//     if (error.code === 'storage/object-not-found') {
//       console.warn("El archivo a eliminar no se encontró en Storage (puede que ya haya sido borrado):", fileUrl);
//     } else {
//       console.error("Error al eliminar el archivo de Firebase Storage:", error);
//       throw new Error(`Error al eliminar el archivo: ${error.message}`);
//     }
//   }
// };
// Nota: Para usar deleteFileByUrl, necesitarías importar `deleteObject` de "firebase/storage".
